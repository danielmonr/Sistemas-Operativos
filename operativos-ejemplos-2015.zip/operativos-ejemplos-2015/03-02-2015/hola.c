#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

extern int a; /* la variable a está en otro archivo */
static int b; /* la variable b no se ve desde otro archivo */

char x;
int y = 10;

#define MESSAGE "Hola mundo %d\n"

int main () {
    char *p;
    for(a=0; a<1000000; a++) {
        p = (char *)malloc(sizeof(char)*1024*1024);
        if (((long int)p) < ((long int)0)) {
            printf("Ya no hay memoria asignable\n");
            break;
        }
        printf("%d\n", a);
    }

    printf(MESSAGE, 10);

    return 0;
}

