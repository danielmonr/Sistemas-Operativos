#include <iostream>

using namespace std;

int main () {
    cout << "Hola mundo" << endl;
}
