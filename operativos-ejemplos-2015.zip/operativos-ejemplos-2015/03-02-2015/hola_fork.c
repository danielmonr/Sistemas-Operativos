#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void salida1() { printf("Se ejecuta al exit 1 \n"); }
void salida2() { printf("Se ejecuta al exit 2\n"); }


int main () {
    int id;

    atexit(salida1);
    atexit(salida2);

    id = fork();

    if (id == 0) {
        printf("Soy un hijo\n");
    } else {
        printf("Mi hijo es el %d\n", id);
        wait(0);
        sleep(10);
    }
    printf("Hola mundo mi pid: %d, el de mi padre: %d\n", getpid(), getppid());



    exit(EXIT_SUCCESS);
}
