#include <unistd.h>
#include <signal.h>
#include <stdio.h>

void hola0(int x) { printf("Hola mundo: %d\n", x); }
void hola1(int x) { printf("Hello world: %d\n", x); }
void hola2(int x) { printf("Konichiwa: %d\n", x); }
void hola3(int x) { printf("Bonjour le monde: %d\n", x); }
void hola4(int x) { printf("Bongiorno: %d\n", x); }

typedef void (*raro)(int);

raro funciones[5];


int main () {
    int id, i;

    funciones[0] = hola0;
    funciones[1] = hola1;
    funciones[2] = hola2;
    funciones[3] = hola3;
    funciones[4] = hola4;

    if( !(id = fork()) ) {
        signal(10, funciones[rand()%4]);
        while(1) {
            pause();
            signal(10, funciones[rand()%4]);
        }
        return;
    }

    while(1) {
        sleep(1);
        kill(id, 10);
    }

}
