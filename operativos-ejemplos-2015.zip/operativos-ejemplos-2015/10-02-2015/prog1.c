#include <unistd.h>
#include <signal.h>
#include <stdio.h>

void hola(int x) {
    printf("Hola mundo: %d\n", x);
}


int main () {
    signal(10, hola);




    while(pause());
}
