#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define READ 0
#define WRITE 1

#define BUFSIZE 32

int main() {
    int fd[2];
    char buffer[BUFSIZE];

    pipe(fd);

    if(!fork()) {
        bzero(buffer, BUFSIZE);
        read(fd[READ], buffer, BUFSIZE);
        printf("buffer: %s", buffer);
        return;
    }

    sleep(2);
    printf("Enviando mensaje al hijo\n");
    strcpy(buffer, "Hola mundo\n");
    write(fd[WRITE], buffer, BUFSIZE);

}
