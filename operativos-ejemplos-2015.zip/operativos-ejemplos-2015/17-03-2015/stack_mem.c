#include <pthread.h>
#include <stdio.h>

/* Por qué los threads tienen el mismo id? Se debe a la candelarizacion del SO, ya que al no saber el orden, los threads lee la variable global y ven el ultimo valor, le da prioridad al for. para solucionarlo se puede utilizarlo pthread_mutex*/

void *thread(void *p) {
    int id;

    id = *(int *)p;

    printf("Mi id es %d\n", id);
}

int main () {
    int id=0, i;
    pthread_t t;

    for (i=0; i<5; i++) {
        id++;
        printf("%d\n", id);
        pthread_create(&t, 0, thread, &id);
    }
    pthread_exit(0);
}
