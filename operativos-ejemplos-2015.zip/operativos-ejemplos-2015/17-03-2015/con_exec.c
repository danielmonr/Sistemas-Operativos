#include <unistd.h>
#include <stdio.h>

/* En dónde está el ciclo? */

int main(int argc, char *argv[]) {
    char buffer[16];
    int n;

    if(argc == 1) {
        sprintf(buffer, "%d", 0);
    } else {
        n = atoi(argv[1]);
        if (n == 10) execl("fin", "fin", (char*)NULL);
        sprintf(buffer, "%d", n+1);
    }

    fprintf(stderr, "%s\n", buffer);
    execl(argv[0], argv[0], buffer, (char*)NULL);
}

