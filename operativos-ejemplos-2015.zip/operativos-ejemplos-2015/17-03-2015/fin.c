#include <stdio.h>

int main() {
    printf("Fin\n");
}
