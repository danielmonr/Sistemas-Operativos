#include <stdio.h>

/* Con cuántos bytes truena el programa?
 * Por qué?
 */

int func() {
    char buffer[0];
    scanf("%s", buffer);
}

int main() {
    func();
    printf("Regreso de la funcion\n");
}
