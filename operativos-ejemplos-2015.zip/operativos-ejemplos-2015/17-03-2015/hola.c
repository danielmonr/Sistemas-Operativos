#include <stdio.h>

/* Por qué imprime?
 * Cómo lo hace? aqui lo que pasa es que el int se esta convirtiendo en char, y el offset logrado hace que se convierta en hola
 */
int main() {
    int i, a;

    a = 1634496360;
    for(i=0; i<4; i++) {
        printf("%c", *(((char *)&a)+i));
    }
    printf("\n");
}
