#include <stdio.h>
#include <stdlib.h>

int x = 9;
int y;

int main() {
    int z;
    char *p = malloc(sizeof(char));

    printf("main (text):\t%012lx\n", main);
    printf("main (data):\t%012lx\n", &x);
    printf("main (bss):\t%012lx\n", &y);

    printf("main (heap):\t%012lx\n", p);
    printf("main (stack):\t%012lx\n", &z);
}
