#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include "sem.h"
#include "mem.h"

#define MUTEX 0

#define FNAME "archivo.bin"

int sems;
int *segmento;

void escritor() {
	int tabla;
	srand(getpid());
        char n[1];
        int i;

	*n = 0;

        int fd;
        fd = open(FNAME, O_CREAT | O_TRUNC | O_WRONLY, 00600);
	for (i=0; i<100; i++) {
                write(fd, n, 1);
	}
        close(fd);

        fd = open(FNAME, O_WRONLY);

	do {
		Wait(sems, MUTEX);
		*segmento = rand()%20;
		Signal(sems, MUTEX);

                printf("Escritor: sobre el bloque %d, %d-%d.\n", *segmento, *segmento*5, *segmento*5+5);

                lseek(fd, *segmento*5, SEEK_SET);
		// que tabla voy a escribir
		tabla = ((int)*segmento/2)+1;
		// desde el 1 o desde el 6 ?
		if ( *segmento%2 != 0) {
			*n = tabla * 6;
		} else {
			*n = tabla;
		}
		for (i=0; i<5; i++) {	
                        write(fd, n, 1);
			*n += tabla;
		}
		sync();

		sleep(rand()%5);
	} while(1);
}

void lector(int id) {
	int misegmento;
	int fd;
        char n[5];

	srand(getpid());

        fd = open(FNAME, O_RDONLY);

	do {
		misegmento = rand()%20;

		Wait(sems, MUTEX);
		while (misegmento == *segmento) {
			Signal(sems, MUTEX);
			misegmento = rand()%20;
			Wait(sems, MUTEX);
		}
		Signal(sems, MUTEX);

                printf("Lector %d: Intentando bloque %d, %d-%d,", id, misegmento, misegmento*5, misegmento*5+5);
                lseek(fd, misegmento*5, SEEK_SET);
                read(fd, n, 5);

		if (n[0] == 0) {
                        printf("0s.\n");
		} else {
			int i;
                        printf("valores: ");
			for(i=0; i<4; i++) {
                                printf("%d, ", n[i]);
			}
                        printf("%d.\n", n[i]);
		}

		sleep(rand()%5);

	} while(1);

}

int main () {
        int i;

	sems = Getsem(1);
	segmento = (int *)mem(sizeof(int));

	Signal(sems, MUTEX);

	if(!fork()) escritor();
	if(!fork()) lector(1);
	//if(!fork()) lector(2);
	//if(!fork()) lector(3);

	for(i=0; i<4; i++) wait(0);
}
