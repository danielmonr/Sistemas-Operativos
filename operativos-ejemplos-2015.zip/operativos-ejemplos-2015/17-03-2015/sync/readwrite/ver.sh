#!/bin/bash
watch od -t d1 -w10 archivo.bin
