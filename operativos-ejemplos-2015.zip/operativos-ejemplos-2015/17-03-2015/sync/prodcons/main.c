#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "sem.h"
#include "mem.h"

#define MUTEX 0
#define EMPTY 1
#define FULL 2
#define BUFSIZE 20

int sems;
int *in, *out, *buffer;

void productor (int id) {
	int n, pos;
	srand(getpid());

	do {
		n = rand();

		Wait(sems, EMPTY);
		Wait(sems, MUTEX);

		buffer[*in] = n;
		pos = *in;
		*in = (*in+1)%BUFSIZE;

		Signal(sems, MUTEX);
		Signal(sems, FULL);

                printf("P %d: Insertando %d en la posicion %d.\n", id, n, pos);
		n = rand()%5;
                printf("P %d: Descansando %d segundos.\n", id, n);

		sleep(n);
	} while(1);
}

void consumidor (int id) {
	int n, pos;
	srand(getpid());

	do {
		Wait(sems, FULL);
		Wait(sems, MUTEX);

		n = buffer[*out];
		pos = *out;
		*out = (*out+1)%BUFSIZE;

		Signal(sems, MUTEX);
		Signal(sems, EMPTY);
		
                printf("C %d: Tomando %d de la posicion %d.\n", id, n, pos);
		n = rand()%5;
                printf("C %d: Descansando %d segundos.\n", id, n);

		sleep(n);
	} while(1);
}

int main () {
        int i;

	buffer = (int *)mem(sizeof(int)*(BUFSIZE+2));
	in = buffer+20;
	out = buffer+21; // o in+1

	*in = *out = 0;

	sems = Getsem(3);
	// 0-mutex, 1-emtpy, 2-full

	Signal(sems, MUTEX);
	for(i=0; i<20; i++) Signal(sems, EMPTY);

	if(!fork()) productor(1);
	if(!fork()) productor(2);
	if(!fork()) consumidor(1);
	if(!fork()) consumidor(2);

	for(i=0; i<4; i++) wait(0);
}
