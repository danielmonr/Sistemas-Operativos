#include <unistd.h>
#include "mem.h"

char *mem(int size) {
    int id;
    char *shmem;

    id = shmget(MY_KEY, size, IPC_CREAT | SEC_MASK);
    shmem = (char *)shmat(id, 0, 0);

    return shmem;
}
