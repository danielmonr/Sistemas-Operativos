#ifndef SEM_H
#define SEM_H

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "key.h"
 
char *mem(int size);

#endif 
