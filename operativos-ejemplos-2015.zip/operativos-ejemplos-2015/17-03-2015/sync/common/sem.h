#ifndef SEMAPHORES_H
#define SEMAPHORES_H

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include "key.h"


int Getsem(int n);
int Signal(int id, int n);
int Wait(int id, int n);

#endif
