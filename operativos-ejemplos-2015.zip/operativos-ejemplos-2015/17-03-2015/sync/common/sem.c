#include "sem.h"

int Getsem(int n) {
    int id, semkey;

    id = semget(MY_KEY, n, IPC_CREAT | SEC_MASK);
    if (id < 0) {
		perror("semget");
		exit(-1);
    }
    return id;
}

int Signal(int id, int n) {
	struct sembuf oper[1];

	oper[0].sem_num = n;
	oper[0].sem_op = 1;
	oper[0].sem_flg = 0;

	if (semop(id, oper, 1) < 0) {
		perror("signal semop");
		exit(-1);
	}
        return 0;
}

int Wait(int id, int n) {
	struct sembuf oper[1];

	oper[0].sem_num = n;
	oper[0].sem_op = -1;
	oper[0].sem_flg = 0;

	if (semop(id, oper, 1) < 0) {
		perror("signal semop");
		exit(-1);
	}
        return 0;
}
