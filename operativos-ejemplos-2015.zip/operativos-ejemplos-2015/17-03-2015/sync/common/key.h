#ifndef KEY_H
#define KEY_H

#define MY_KEY 724112

#define SEC_MASK 0700

#endif
