#include <pthread.h>
#include <stdio.h>

/* En qué momento cambian los valores del arreglo? */
/* Es por el offset que toma en que el array es int midiendo 4 y void mide 1, por lo que se i se multiplica por 4 se arregla ese offset*/
void *thread(void *p) {
    int i;

    for (i=0; i<5; i++) {
        printf("array[%d]=%d\n", i, *(int *)(p + (i*4)));
    }

}

int main () {
    int array[5], i;
    pthread_t t;

    for (i=0; i<5; i++) {
        array[i] = i;
        printf("array[%d]=%d\n", i, array[i]);
    }
    pthread_create(&t, 0, thread, array);
    pthread_exit(0);
}
