#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>

pthread_t t1, t2;
unsigned int id;
char z;

typedef struct {
    char a;
} raro;

int i;

void *f1(void *p) {
    for (i=0; i<10; i++) {
        printf("Hola mundo %d: %d\n", i, t1);
        usleep(100);
    }
    return &z;
}
void *f2(void *p) {
    for (i=0; i<10; i++) {
        printf("Hola mundo %d: %d\n", i, t2);
        usleep(100);
    }
    return &z;
}

int main () {
    void *resultado = NULL;

    pthread_attr_t a;
    pthread_attr_init(&a);

    pthread_create(&t1, &a, f1, NULL);
    pthread_create(&t2, &a, f2, NULL);
    pthread_join(t1, &resultado); 
    pthread_join(t2, &resultado); 


}
